package com.example.qrcode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;

public class MainActivity extends AppCompatActivity {
    EditText qrval;
    Button generate,scan;
    ImageView QR;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qrval=findViewById(R.id.qrinput);
        generate=findViewById(R.id.generate);
        scan=findViewById(R.id.scan);
        QR=findViewById(R.id.QR);

        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String data=qrval.getText().toString();
                QRGEncoder qrgEncoder=new QRGEncoder(data,null,QRGContents.Type.TEXT,500);
                try {
                    Bitmap qrBits=qrgEncoder.getBitmap();
                    QR.setImageBitmap(qrBits);
                }catch (Exception e){
                    e.printStackTrace();
                }


            }
        });

        scan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(getApplicationContext(),Scanner.class));
                    }
                }
        );
    }
}